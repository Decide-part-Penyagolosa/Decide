import logging
import json
import requests
from telegram import ReplyKeyboardMarkup, ReplyKeyboardRemove
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters,ConversationHandler
from utilities import global_vars,parser,crypto
import os

API_DECIDE = 'http://127.0.0.1:8000/'
BOT_TOKEN = '5061816889:AAFSjO0WEToxu2gGVvN47pVdTFDfju71fEg'

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    level=logging.INFO)

logger = logging.getLogger(__name__)

LOGIN, STORE, VOTINGS, VOTING, SAVE_VOTE  = range(5)


def get_token(credentials):

    r = requests.post(API_DECIDE + "authentication/login/", credentials)

    return r


def get_votings(id):

    r = requests.get(API_DECIDE + "voting/user/?id="+str(id))
    return r


def get_user(token):
    data = {'token': token}
    r = requests.post(API_DECIDE + "authentication/getuser/", data)
    return r

def save_vote_data(data_dict):
    
    headers = {"Authorization": "Token " + data_dict['token'],
                "Content-Type": "application/json"}
    
    r = requests.post(API_DECIDE + "store/", json=data_dict, headers = headers)

    print(r.status_code)
    return r



def login(update, context):
    user = update.message.from_user
    logger.info("%s  %s", user.first_name, update.message.text)
    update.message.reply_text("Indique su nombre de usuario y tu contraseña de la siguiente forma. \nUsername \nContraseña",
                              reply_markup=ReplyKeyboardRemove())
    return STORE

def store(update, context):
    credentials = {}
    next_state = ConversationHandler.END
    for index, i in enumerate(update.message.text.split("\n")):
        if index == 0:
            credentials["username"] = i
        else:
            credentials["password"] = i

    response = get_token(credentials)
    if response.status_code == 200:
        global_vars.token = json.loads(response.text)["token"]
        username = credentials['username']
        update.message.reply_text("¡Ya has iniciado sesión, " + username + "!")
        user = update.message.from_user
        logger.info("Usuario  %s logged", user.first_name)
        reply_keyboard = [['Vote']]
        update.message.reply_text(update.message.text, reply_markup=ReplyKeyboardMarkup(
            reply_keyboard, one_time_keyboard=True))
        next_state = VOTINGS
    else:
        update.message.reply_text(
            "Los credenciales son incorrectos, índicalos o escribe /cancel para salir")
        next_state = STORE

    return next_state

def start(update, context):
    update.message.reply_text('Hi!')
    #reply_keyboard = [['Login']]
    #update.message.reply_text(
     #   'Hi! My name is EGC_decide_bot. Lets vote',
      #  reply_markup=ReplyKeyboardMarkup(reply_keyboard, one_time_keyboard=True))

    #return LOGIN


def votings(update, context):
    response = get_user(global_vars.token)
    usuario = json.loads(response.text)

    response2 = get_votings(usuario["id"])

    vots = json.loads(response2.text)
    votaciones = parser.parseVotings(vots)
    global_vars.user_votings = votaciones
    reply_keyboard = parser.createKeybVoting(votaciones)
    update.message.reply_text(update.message.text, reply_markup=ReplyKeyboardMarkup(
        reply_keyboard, one_time_keyboard=True))
    logger.info("Listing votings")
    return VOTING


def voting(update, context):
    global_vars.voting_selected = update.message.text.split("-")[0]
    voting = parser.parseVoting()
    reply_keyboard = parser.createKeyOption(voting['question']['options'])

    update.message.reply_text(update.message.text, reply_markup=ReplyKeyboardMarkup(
        reply_keyboard, one_time_keyboard=True))
    logger.info("Listing voting options")
    
    return SAVE_VOTE

def save_vote(update,context):
    selected_option_id=update.message.text.split('-')[0]
    pub_key_encrypt=crypto.PublicKey(int(global_vars.pub_key.get('p')),int(global_vars.pub_key.get('g')),int(global_vars.pub_key.get('y')))
    vote_encrypt=crypto.encrypt(pub_key_encrypt,selected_option_id)

    user_by_token=get_user(global_vars.token)
    usuario = json.loads(user_by_token.text)
    user_id=usuario['id']

    vote_encrypt=vote_encrypt.split()

    data_dict={'vote':{'a':vote_encrypt[0],'b': vote_encrypt[1]},
    'voting' :global_vars.voting_selected,
    'voter':user_id,
    'token': global_vars.token
    }

    save_vote_data(data_dict)

    update.message.reply_text('La votación ha sido realizada con éxito.', reply_markup=ReplyKeyboardRemove())
    return ConversationHandler.END    

def cancel(update, context):
    user = update.message.from_user
    logger.info("User %s canceled the conversation.", user.first_name)
    update.message.reply_text('Bye! You canceled the conversation, see you later.',
                              reply_markup=ReplyKeyboardRemove())

    return ConversationHandler.END

def error(update, context):
    """Log Errors caused by Updates."""
    logger.warning('Update "%s" caused error "%s"', update, context.error)
    update.message.reply_text('An error has ocurred when you were voting, restart the voting process with "/start".',
                            reply_markup=ReplyKeyboardRemove())   

    return ConversationHandler.END









def main():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    conv_handler = ConversationHandler(
        entry_points=[CommandHandler('start', start)],

        states={
            LOGIN: [MessageHandler(Filters.regex('^(Login)$'), login)],

            STORE: [MessageHandler(Filters.text, store)],

            VOTINGS: [MessageHandler(Filters.regex('^(Vote)$'), votings)],

            VOTING: [MessageHandler(Filters.text, voting)],

            SAVE_VOTE: [MessageHandler(Filters.text,save_vote)]
        },

        fallbacks=[CommandHandler('cancel', cancel)]
    )

    dp.add_handler(conv_handler)

    # log all errors
    dp.add_error_handler(error)

   # if(config.WEBHOOK):
    #    logger.info("WEBHOOK ACTIVADO")
     #   PORT = int(os.environ.get("PORT", config.PORT))
      #  updater.start_webhook(listen="0.0.0.0",
       #                       port=PORT,
        #                      url_path=config.BOT_TOKEN)
        #updater.bot.set_webhook("https://{}.herokuapp.com/{}".format(config.HEROKU_APP_NAME, config.BOT_TOKEN))
    #else:
     #   updater.start_polling()

    updater.idle()








if __name__ == '__main__':
    main()

token = ""
voting_selected = {}
user_votings={}
pub_key={}
